/**
 * ============================================================
 * App.js - メインコンポーネント
 * ============================================================
 * このファイルはアプリの中心となるコンポーネントです。
 * すべての状態（データ）を管理し、各コンポーネントに渡します。
 *
 * コンポーネント構成:
 *   App
 *   ├── Header（タイトルバー）
 *   ├── HabitatList（生息地一覧）左側
 *   └── MaterialPanel（素材合計パネル）右側
 * ============================================================
 */

import React, { useState, useEffect, useMemo } from "react";
import Header from "./components/Header";
import HabitatList from "./components/HabitatList";
import MaterialPanel from "./components/MaterialPanel";
import "./App.css";

/**
 * App コンポーネント
 * アプリ全体の状態管理と大まかなレイアウトを担当します
 */
function App() {
  // ============================================================
  // State（状態）の定義
  // useState は React の「記憶」機能。値が変わると画面が再描画される
  // ============================================================

  /** 全生息地データ（サーバーから取得） */
  const [habitats, setHabitats] = useState([]);

  /** 作成済み生息地IDのセット。例: { "habitat_1", "habitat_5", ... } */
  const [completedIds, setCompletedIds] = useState(() => {
    // ページ読み込み時にLocalStorageから復元する
    // () => {...} という書き方で、初回のみ実行される初期化関数を指定できる
    try {
      const saved = localStorage.getItem("completedHabitats");
      // 保存データがあればJSON解析してSetに変換、なければ空のSetを返す
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch {
      // 万が一データが壊れていたら空のSetを返す
      return new Set();
    }
  });

  /** 検索テキスト */
  const [searchText, setSearchText] = useState("");

  /** 「未作成のみ表示」フィルターのON/OFF */
  const [showOnlyIncomplete, setShowOnlyIncomplete] = useState(false);

  /** データ読み込み中かどうか */
  const [isLoading, setIsLoading] = useState(true);

  /** エラーメッセージ（読み込み失敗時） */
  const [error, setError] = useState(null);

  // ============================================================
  // useEffect - 副作用の処理
  // コンポーネントのレンダリング後に実行される処理を書く場所
  // ============================================================

  /**
   * 初回マウント時にサーバーからデータを取得する
   * [] を第2引数に指定すると「最初の1回だけ実行」になる
   */
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        // バックエンドAPIから生息地データを取得
        // package.jsonの "proxy": "http://localhost:3001" のおかげで
        // /api/habitats だけで http://localhost:3001/api/habitats にアクセスできる
        const response = await fetch("/api/habitats");

        // HTTPエラーチェック（404, 500などの場合）
        if (!response.ok) {
          throw new Error(`サーバーエラー: ${response.status}`);
        }

        const result = await response.json();
        setHabitats(result.data); // 取得したデータをstateに保存
      } catch (err) {
        // ネットワークエラーやサーバーエラーの場合
        setError(`データの取得に失敗しました: ${err.message}`);
        console.error("データ取得エラー:", err);
      } finally {
        // 成功・失敗に関わらず最後に実行される
        setIsLoading(false);
      }
    };

    fetchData();
  }, []); // 依存配列が空 = 初回のみ実行

  /**
   * completedIds が変わるたびにLocalStorageに保存する
   * これにより、ページをリロードしても状態が保持される
   */
  useEffect(() => {
    // Setは直接JSONにできないので、配列に変換してから保存
    localStorage.setItem(
      "completedHabitats",
      JSON.stringify([...completedIds])
    );
  }, [completedIds]); // completedIdsが変わったら実行

  // ============================================================
  // ハンドラ関数（ユーザー操作に反応する関数）
  // ============================================================

  /**
   * チェックボックスが操作されたときの処理
   * @param {string} habitatId - 操作された生息地のID
   */
  const handleToggleComplete = (habitatId) => {
    setCompletedIds((prev) => {
      // 新しいSetを作る（元のSetを直接変更しないのがReactの基本）
      const next = new Set(prev);
      if (next.has(habitatId)) {
        next.delete(habitatId); // チェック済みなら解除
      } else {
        next.add(habitatId); // 未チェックならチェック
      }
      return next;
    });
  };

  /**
   * 全チェックをリセットする処理
   */
  const handleReset = () => {
    if (window.confirm("全ての「作成済み」状態をリセットしますか？")) {
      setCompletedIds(new Set());
    }
  };

  // ============================================================
  // useMemo - パフォーマンス最適化
  // 依存する値が変わったときだけ再計算される
  // ============================================================

  /**
   * 検索・フィルターを適用した生息地リストを計算する
   * habitats, searchText, showOnlyIncomplete, completedIds のどれかが変わったら再計算
   */
  const filteredHabitats = useMemo(() => {
    return habitats.filter((habitat) => {
      // 検索テキストでフィルタリング（大文字小文字を区別しない）
      const matchesSearch = habitat.name
        .toLowerCase()
        .includes(searchText.toLowerCase());

      // 「未作成のみ」フィルタリング
      const matchesFilter = showOnlyIncomplete
        ? !completedIds.has(habitat.id) // 未作成のみONなら、完了していないものだけ
        : true; // OFFなら全て通す

      return matchesSearch && matchesFilter;
    });
  }, [habitats, searchText, showOnlyIncomplete, completedIds]);

  /**
   * 未作成の生息地に必要な素材の合計を計算する
   * この関数が最も重要な集計ロジックです
   */
  const requiredMaterials = useMemo(() => {
    // 素材名をキーに、必要数の合計を値とするオブジェクトを作る
    const totals = {}; // 例: { "Material 1": 15, "Material 5": 32, ... }

    habitats.forEach((habitat) => {
      // 作成済みの生息地はスキップ
      if (completedIds.has(habitat.id)) return;

      // この生息地の各素材を集計
      habitat.materials.forEach(({ materialName, quantity }) => {
        if (totals[materialName]) {
          totals[materialName] += quantity; // 既にあれば加算
        } else {
          totals[materialName] = quantity; // 初めてなら追加
        }
      });
    });

    // オブジェクトをソート済み配列に変換して返す（必要数の多い順）
    return Object.entries(totals)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count); // 降順ソート
  }, [habitats, completedIds]);

  // ============================================================
  // 統計情報の計算
  // ============================================================
  const totalCount = habitats.length;
  const completedCount = completedIds.size;
  const incompleteCount = totalCount - completedCount;
  const progressPercent =
    totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // ============================================================
  // レンダリング（画面の描画）
  // ============================================================
  return (
    <div className="app-container">
      {/* ヘッダー（タイトル・進捗バー） */}
      <Header
        totalCount={totalCount}
        completedCount={completedCount}
        incompleteCount={incompleteCount}
        progressPercent={progressPercent}
        onReset={handleReset}
      />

      {/* メインコンテンツ（左右レイアウト） */}
      <div className="main-layout">
        {/* 左側：生息地一覧 */}
        <div className="left-panel">
          <HabitatList
            habitats={filteredHabitats}
            completedIds={completedIds}
            searchText={searchText}
            showOnlyIncomplete={showOnlyIncomplete}
            isLoading={isLoading}
            error={error}
            onToggleComplete={handleToggleComplete}
            onSearchChange={setSearchText}
            onFilterChange={setShowOnlyIncomplete}
          />
        </div>

        {/* 右側：必要素材合計パネル（固定表示） */}
        <div className="right-panel">
          <MaterialPanel
            materials={requiredMaterials}
            incompleteCount={incompleteCount}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
