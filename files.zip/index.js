/**
 * ============================================================
 * バックエンドサーバー (Node.js + Express)
 * ============================================================
 * このファイルはAPIサーバーの本体です。
 * フロントエンド（React）からHTTPリクエストを受け取り、
 * データを返す役割を担います。
 * ============================================================
 */

// --- 必要なライブラリを読み込む ---
const express = require("express"); // Webサーバーを作るためのライブラリ
const cors = require("cors"); // 異なるオリジン（ポート）からのアクセスを許可する設定

// --- Expressアプリを初期化 ---
const app = express();
const PORT = 3001; // サーバーが動くポート番号（フロントは3000なので3001を使う）

// --- ミドルウェアの設定 ---
app.use(cors()); // CORSを有効化（React開発サーバー localhost:3000 からのアクセスを許可）
app.use(express.json()); // リクエストボディをJSON形式で受け取れるようにする

// ============================================================
// モックデータ自動生成
// ============================================================
/**
 * 全素材リストを生成する関数
 * Material 1 〜 Material 100 の100種類を生成します
 */
function generateMaterials() {
  const materials = [];
  for (let i = 1; i <= 100; i++) {
    materials.push({
      id: `material_${i}`, // 例: "material_1"
      name: `Material ${i}`, // 例: "Material 1"
    });
  }
  return materials;
}

/**
 * 全生息地リストを生成する関数
 * Habitat 1 〜 Habitat 209 の209件を生成します
 * 各生息地にはランダムで1〜5種類の素材が割り当てられます
 *
 * @param {Array} materials - 素材リスト（generateMaterials()の結果）
 */
function generateHabitats(materials) {
  const habitats = [];

  // シードありの疑似ランダム（毎回同じデータになるようにする）
  // Math.random()は毎回変わってしまうので、簡易的な固定シードを使用
  let seed = 42;
  function pseudoRandom() {
    // 線形合同法による疑似乱数生成
    seed = (seed * 1664525 + 1013904223) & 0xffffffff;
    return Math.abs(seed) / 0x7fffffff;
  }

  for (let i = 1; i <= 209; i++) {
    // この生息地で必要な素材の種類数（1〜5種類）
    const materialCount = Math.floor(pseudoRandom() * 5) + 1;

    // 使用する素材をランダムに選ぶ（重複なし）
    const selectedMaterials = [];
    const usedIndices = new Set(); // 同じ素材を2回選ばないための管理セット

    for (let j = 0; j < materialCount; j++) {
      let idx;
      // 重複しないインデックスが見つかるまでループ
      do {
        idx = Math.floor(pseudoRandom() * materials.length);
      } while (usedIndices.has(idx));

      usedIndices.add(idx);

      selectedMaterials.push({
        materialId: materials[idx].id, // 素材のID
        materialName: materials[idx].name, // 素材の名前
        quantity: Math.floor(pseudoRandom() * 10) + 1, // 必要数（1〜10個）
      });
    }

    habitats.push({
      id: `habitat_${i}`, // 例: "habitat_1"
      name: `Habitat ${i}`, // 例: "Habitat 1"
      materials: selectedMaterials, // この生息地に必要な素材リスト
    });
  }

  return habitats;
}

// --- データを生成してメモリに保持 ---
// ※ 本番ではデータベース（MySQL, PostgreSQLなど）を使いますが、
//    今回は学習目的のためメモリ内に保存します
const MATERIALS = generateMaterials();
const HABITATS = generateHabitats(MATERIALS);

// ============================================================
// APIエンドポイント
// ============================================================

/**
 * GET /api/materials
 * 全素材リストを返す
 */
app.get("/api/materials", (req, res) => {
  console.log("[GET] /api/materials が呼ばれました"); // サーバーログ
  res.json({
    success: true,
    data: MATERIALS,
  });
});

/**
 * GET /api/habitats
 * 全生息地リストを返す
 */
app.get("/api/habitats", (req, res) => {
  console.log("[GET] /api/habitats が呼ばれました"); // サーバーログ
  res.json({
    success: true,
    data: HABITATS,
  });
});

// --- サーバーを起動する ---
app.listen(PORT, () => {
  console.log(`✅ サーバーが起動しました: http://localhost:${PORT}`);
  console.log(`📦 生息地数: ${HABITATS.length}件`);
  console.log(`🧪 素材数: ${MATERIALS.length}種類`);
});
